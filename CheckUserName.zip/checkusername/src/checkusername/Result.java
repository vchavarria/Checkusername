package checkusername;

public class Result {

	public boolean isValid;
	public String[] names;

}
